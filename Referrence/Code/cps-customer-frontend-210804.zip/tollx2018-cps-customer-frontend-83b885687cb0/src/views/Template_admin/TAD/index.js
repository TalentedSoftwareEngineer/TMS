import TAD from './TAD';

export default TAD;
