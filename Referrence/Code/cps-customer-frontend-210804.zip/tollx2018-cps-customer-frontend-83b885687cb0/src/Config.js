const Config = {
  basePath: '/customer',
  eventSourceEndPoint: '/api/v1',
  apiEndPoint: '/api/v1/customer/',
}

export default Config;
