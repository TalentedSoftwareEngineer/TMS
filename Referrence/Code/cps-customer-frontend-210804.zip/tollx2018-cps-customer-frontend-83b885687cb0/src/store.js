
import createStore from './redux';

const store = createStore();

export default store;
