export const environment = {
	production: true,
	api: {
		core: {
			uri: 'http://208.73.236.221:3002',
			path: '/api/v1'
		},
		ws: {
			uri: 'ws://{{HOST_IP}}:8081'
		}
	},
  stripe: {
    key: "pk_test_51LfINzFpiPklWkrVtqhZUhdonvVgrSpcPDbLaxNGOtzd2wpc1BoLvPUHUUk4Zk5NFpRLo0Ou7jVcXN2TSiI2FN8100zR9TY5Hl"
  }
};
