export interface NumberMan {
  id?: number;
  name: string;
  npa: string;
  number: string;
  nxx: string;
  prov_id: number;
  ratecenter: string;
  recur: string;
  setup_fee: string;
  state: string;
  type: string;
}
