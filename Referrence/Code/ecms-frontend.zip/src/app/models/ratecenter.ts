export interface Ratecenter {
  id?: number;
  footprint_id: number,
  rate_center: string
}
