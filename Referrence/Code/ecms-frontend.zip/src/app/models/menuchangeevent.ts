export interface MenuChangeEvent {
    key: string;
    routeEvent?: boolean;
}