import { FixedPipe } from './fixed.pipe';

describe('FixedPipe', () => {
  it('create an instance', () => {
    const pipe = new FixedPipe();
    expect(pipe).toBeTruthy();
  });
});
