import { FixedTimePipe } from './fixed-time.pipe';

describe('FixedTimePipe', () => {
  it('create an instance', () => {
    const pipe = new FixedTimePipe();
    expect(pipe).toBeTruthy();
  });
});
