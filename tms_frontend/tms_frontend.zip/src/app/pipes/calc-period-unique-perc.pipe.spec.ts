import { CalcPeriodUniquePercPipe } from './calc-period-unique-perc.pipe';

describe('CalcPeriodUniquePercPipe', () => {
  it('create an instance', () => {
    const pipe = new CalcPeriodUniquePercPipe();
    expect(pipe).toBeTruthy();
  });
});
