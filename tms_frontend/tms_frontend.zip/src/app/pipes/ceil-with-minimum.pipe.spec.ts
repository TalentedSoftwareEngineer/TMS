import { CeilWithMinimumPipe } from './ceil-with-minimum.pipe';

describe('CeilWithMinimumPipe', () => {
  it('create an instance', () => {
    const pipe = new CeilWithMinimumPipe();
    expect(pipe).toBeTruthy();
  });
});
