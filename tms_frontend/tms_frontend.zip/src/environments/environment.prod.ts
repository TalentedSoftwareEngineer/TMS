export const environment = {
  production: true,
  // base_uri: 'http://208.76.96.11:3000/api/v1',
  // stream_uri: 'https://208.76.96.11:6379/stream'
  base_uri: 'https://tmsdev.tfnms.com:3000/api/v1',
  stream_uri: 'https://tmsdev.tfnms.com:6379/stream',
};
